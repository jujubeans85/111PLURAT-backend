# test_mongo.py — quick connection test
from pymongo import MongoClient
MONGO_URI = "mongodb+srv://<username>:<password>@cluster0.abcd1.mongodb.net/?retryWrites=true&w=majority"
try:
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    client.admin.command("ping")
    print("✅ Connected OK:", client.list_database_names())
except Exception as e:
    print("❌ Connection failed:", e)
